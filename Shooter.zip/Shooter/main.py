import pygame
import random
import math
from pygame import mixer
# initialize the Pygame
pygame.init()
screen=pygame.display.set_mode((800,600))

running=True

#Title and Icon
pygame.display.set_caption("Go_Corona_Go")
icon=pygame.image.load("Corona_shooter.png") 
pygame.display.set_icon(icon)

# Background
background=pygame.image.load('background.jpg')
#Background Music
mixer.music.load('background.mp3')
mixer.music.play(-1)

#Player
playerImg=pygame.image.load("gaming.png")
playerX = 370
playerY = 480
playerX_change=0
playerY_change=0

#Corona 

coronaX=[]
coronaY=[]
coronaImg=[]
coronaX_change=[]
coronaY_change=[]
num_of_enimies=6

for i in range(num_of_enimies): 
	coronaImg.append(pygame.image.load("bacteria.png"))
	coronaX.append(random.randint(0,736))
	coronaY.append(random.randint(50,300))
	coronaX_change.append(4)
	coronaY_change.append(40)

#Bullet
 

bulletImg=pygame.image.load('weapons.png')
bulletX=0
bulletY= 480 
bulletX_change=0
bulletY_change=10
bullet_state='ready'


Virus_Killed=0
font =pygame.font.Font('freesansbold.ttf',32)
fontX=10
fontY=10


gameover=pygame.font.Font('freesansbold.ttf',64)

def g():
	gm=gameover.render("---- You Became CORONA +VE ---- ",True,(255,255,255))
	screen.blit(gm,(200,250))

def VirusKilled(x,y):
	score=font.render("Virus Killed :"+str(Virus_Killed),True,(255,255,255))
	screen.blit(score,(x,y))

def player(x,y):
	screen.blit(playerImg,(x,y))

def corona(x,y,i):
	screen.blit(coronaImg[i] , (x, y))

def shoot(x,y):
	global bullet_state
	bullet_state= 'fired'
	screen.blit(bulletImg,(x+16 ,y+10))

def isBusted(playerX,playerY,coronaX,coronaY):
	distance =math.sqrt(math.pow(playerX-coronaX,2)+math.pow(playerY-coronaY,2))
	if distance < 57:
		return True
	else:
		False

def isCollision(bulletX,bulletY,coronaX,coronaY):
	distance = math.sqrt(math.pow(bulletX-coronaX,2) + math.pow(bulletY-coronaY,2))
	if distance <27 :
		return True
	else:
		False

#Game Loop
while running:
	screen.fill((0,0,0))
	screen.blit(background,(0,0))
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			running = False


	# if key stroke is pressed check whether its right or wrong
		if event.type == pygame.KEYDOWN:
			# Moving Left and Right
			if event.key ==pygame.K_LEFT:
				playerX_change =-5
			if event.key == pygame.K_RIGHT:
				playerX_change = 5

			if event.key == pygame.K_SPACE:
				if bullet_state is 'ready':
					bullet_Sound=mixer.Sound('laser.wav')
					bullet_Sound.play()
					bulletX=playerX
					shoot(bulletX,bulletY)			

		if event.type == pygame.KEYUP:
			if event.key== pygame.K_LEFT or event.key == pygame.K_RIGHT  :
				playerX_change = 0
		

	playerX += playerX_change

	if playerX <= 0:
		playerX =0
	elif playerX >= 736:
		playerX =736

    
	
	for i in range(num_of_enimies):    
		coronaX[i] +=coronaX_change[i]

		if coronaX[i] <= 0:
			coronaX_change[i] = 4
			coronaY[i] += coronaY_change[i]
		elif coronaX[i] >= 736:
			coronaX_change[i] = -4
			coronaY[i] +=coronaY_change[i]

		#Collision
		collision=isCollision(bulletX,bulletY,coronaX[i],coronaY[i])

		if collision:
			explosion_sound =mixer.Sound('explosion.wav')
			explosion_sound.play()
			bulletY=480
			bullet_state="ready"
			Virus_Killed +=1 
			coronaX[i] =random.randint(0,736)
			coronaY[i]=random.randint(50,150)

		Busted = isBusted(playerX,playerY,coronaX[i],coronaY[i])
		if Busted:
			explosion_sound =mixer.Sound('explosion.wav')
			explosion_sound.play()
			for j in range(num_of_enimies):
				coronaX[j] = 2000 
				coronaY[j] = 2000

				g()
				

			
		        
		corona(coronaX[i],coronaY[i],i)	

	if bulletY <=0:
		bulletY =480
		bullet_state='ready'

	if bullet_state is "fired":
		shoot(bulletX,bulletY)
		bulletY -= bulletY_change

	
	


	player(playerX,playerY)
	VirusKilled(fontX,fontY)
	pygame.display.update()